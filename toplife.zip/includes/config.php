<?php

define("DB_HOST", "mysql.hostinger.ru");
define("DB_USER", "u681311792_svd");
define("DB_PASS", "zxcasdqwe123");
define("DB_NAME", "u681311792_svd");
