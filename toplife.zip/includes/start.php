<?php

// session_cache_limiter(false);
session_start();

ini_set("display_errors", "On");
